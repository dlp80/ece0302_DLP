#ifndef _SORT_HPP
#define _SORT_HPP

#include "linked_list.hpp"

template<typename T> LinkedList<T> sort(LinkedList<T> list)
{
    if (list.getLength() <= 1) {
        return list;
    }

    LinkedList<T> left, right;

    // Split list into two halves
    std::size_t middle = list.getLength() / 2;
    for (std::size_t i = 1; i <= middle; ++i) {
        left.insert(i, list.getEntry(i));
    }
    for (std::size_t i = middle+1; i <= list.getLength(); ++i) {
        right.insert(i-middle, list.getEntry(i));
    }

    // Recursively sort the two halves
    left = sort(left);
    right = sort(right);

    // Merge the two sorted halves
    LinkedList<T> result;
    std::size_t i = 1, j = 1;
    while (i <= left.getLength() && j <= right.getLength()) {
        if (left.getEntry(i) <= right.getEntry(j)) {
            result.insert(result.getLength()+1, left.getEntry(i));
            ++i;
        } else {
            result.insert(result.getLength()+1, right.getEntry(j));
            ++j;
        }
    }
    while (i <= left.getLength()) {
        result.insert(result.getLength()+1, left.getEntry(i));
        ++i;
    }
    while (j <= right.getLength()) {
        result.insert(result.getLength()+1, right.getEntry(j));
        ++j;
    }

    return result;
}

#endif

